from PIL import Image, ImageDraw, ImageFont
import os

img = Image.new('RGBA', (512, 512), (0,0,0,0))
draw = ImageDraw.Draw(img)

# Background rounded rect
def rounded_rect(draw, xy, radius, fill):
    x1,y1,x2,y2 = xy
    draw.rectangle([x1+radius, y1, x2-radius, y2], fill=fill)
    draw.rectangle([x1, y1+radius, x2, y2-radius], fill=fill)
    draw.ellipse([x1, y1, x1+2*radius, y1+2*radius], fill=fill)
    draw.ellipse([x2-2*radius, y1, x2, y1+2*radius], fill=fill)
    draw.ellipse([x1, y2-2*radius, x1+2*radius, y2], fill=fill)
    draw.ellipse([x2-2*radius, y2-2*radius, x2, y2], fill=fill)

rounded_rect(draw, (0,0,512,512), 100, (91, 106, 240))

# Simple pick icon
draw.rectangle([220, 100, 292, 412], fill='white')
draw.polygon([(150,150),(362,150),(256,280)], fill='white')

img.save('/home/claude/launcher/icon.png')
print("Icon created")
